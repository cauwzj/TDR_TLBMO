function varargout = SECOND_BMO(varargin)
% SECOND_BMO MATLAB code for SECOND_BMO.fig
%      SECOND_BMO, by itself, creates a new SECOND_BMO or raises the existing
%      singleton*.
%
%      H = SECOND_BMO returns the handle to a new SECOND_BMO or the handle to
%      the existing singleton*.
%
%      SECOND_BMO('CALLBACK',hObject,eventData,handles,...) calls the local
%      function named CALLBACK in SECOND_BMO.M with the given input arguments.
%
%      SECOND_BMO('Property','Value',...) creates a new SECOND_BMO or raises the
%      existing singleton*.  Starting from the left, property value pairs are
%      applied to the GUI before SECOND_BMO_OpeningFcn gets called.  An
%      unrecognized property name or invalid value makes property application
%      stop.  All inputs are passed to SECOND_BMO_OpeningFcn via varargin.
%
%      *See GUI Options on GUIDE's Tools menu.  Choose "GUI allows only one
%      instance to run (singleton)".
%
% See also: GUIDE, GUIDATA, GUIHANDLES

% Edit the above text to modify the response to help SECOND_BMO

% Last Modified by GUIDE v2.5 07-Oct-2014 22:57:47

% Begin initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'gui_OpeningFcn', @SECOND_BMO_OpeningFcn, ...
                   'gui_OutputFcn',  @SECOND_BMO_OutputFcn, ...
                   'gui_LayoutFcn',  [] , ...
                   'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT


% --- Executes just before SECOND_BMO is made visible.
function SECOND_BMO_OpeningFcn(hObject, eventdata, handles, varargin)
% This function has no output args, see OutputFcn.
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% varargin   command line arguments to SECOND_BMO (see VARARGIN)

% Choose default command line output for SECOND_BMO
handles.output = hObject;

% Data Handles
handles.FILENAME=0;
handles.FILEPATH=0;
handles.WAVEFORMDATA=0;
handles.PROBELENGTHDATA=0;
handles.DATALENGTH=0;
handles.DATAWIDTH=0;
handles.WINDOWLENGTH=0;

% Parameters Handles
handles.SAMPLETIME=0.02695467436; % ns
handles.VELOFRACPROPAGATION=0.99; % dimensionless
handles.LIGHTSPEED=299.792458; % mm/ns


% Program Handles
handles.WAVEFORMINDEX=0;
handles.FIRSTREFMETHOD=1;   set(handles.MENU_FIRSTREF_SECOND_BMO,'checked','on');
                            set(handles.MENU_FIRSTREF_TANGENT_LINE,'checked','off');
                            set(handles.MENU_FIRSTREF_TANGENT_HEAP,'checked','off');
                            set(handles.MENU_FIRSTREF_MANUAL,'checked','off');
                            set(handles.CHECK_MANUAL_FIRSTREF,'value',0);
handles.CHECK_SMOOTH=0;
handles.SMOOTHSTRENGTH=0.8;
handles.SENSITIVITYSTRENGTH=0.2;
handles.TEMPW1=0;
handles.TEMPWBMO=0;
handles.TEMPS1=0;
handles.TEMPSBMO=0;
handles.WINDOWLENGTHTIME=0;

% Result Handles
handles.FIRSTREFRES=20;
handles.SECONDREFRES=40;
handles.RELATIVEPERMITTIVTY=0;
handles.VWCTOPP=0;
handles.MARKED=0;

% Plot Handles
handles.AXES_ORIGINAL_WAVEFORM_ORIGINAL=0;
handles.AXES_SECOND_BMO_ORIGINAL=0;
handles.AXES_ORIGINAL_WAVEFORM_SMOOTH=0;
handles.AXES_SECOND_BMO_SMOOTH=0;

handles.AXES_ORIGINAL_WAVEFORM_FIRSTREF=0;
handles.AXES_SECOND_BMO_FIRSTREF=0;
handles.AXES_ORIGINAL_WAVEFORM_SECREF=0;
handles.AXES_SECOND_BMO_SECREF=0;


% Update handles structure
guidata(hObject, handles);

% UIWAIT makes SECOND_BMO wait for user response (see UIRESUME)
% uiwait(handles.figure1);


% --- Outputs from this function are returned to the command line.
function varargout = SECOND_BMO_OutputFcn(hObject, eventdata, handles) 
% varargout  cell array for returning output args (see VARARGOUT);
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Get default command line output from handles structure
varargout{1} = handles.output;


% --------------------------------------------------------------------
function FILE_Callback(hObject, eventdata, handles)
% hObject    handle to FILE (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)


% --------------------------------------------------------------------
function OPERATION_Callback(hObject, eventdata, handles)
% hObject    handle to OPERATION (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)


% --------------------------------------------------------------------
function CALIBRATION_Callback(hObject, eventdata, handles)
% hObject    handle to CALIBRATION (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)


% --------------------------------------------------------------------
function HELP_Callback(hObject, eventdata, handles)
% hObject    handle to HELP (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)


% --------------------------------------------------------------------
function MENU_ABOUT_Callback(hObject, eventdata, handles)
% hObject    handle to MENU_ABOUT (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
WelPrint=sprintf('Welcome to TDR curvature analysis program\nData Format:\n \t Sheet 1: Waveform Data\n \t Sheet 2: Parameters (Probe Length)\n \t Sheet 3: Results\n\n\n\t\t\tSoil Physics Group\n\t\t\tIowa State University\n\t\t\tMay 2013');
questdlg(WelPrint,'ABOUT_TDR','Yes','Yes');

% --------------------------------------------------------------------
function MENU_AUTOCALI_Callback(hObject, eventdata, handles)
% hObject    handle to MENU_AUTOCALI (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

index=handles.WAVEFORMINDEX;
firstref=handles.FIRSTREFRES(index);
secondref=handles.SECONDREFRES(index);
vp=handles.VELOFRACPROPAGATION;
sampletime=handles.SAMPLETIME;
vc=handles.LIGHTSPEED;
L=handles.DATALENGTH;

if firstref==0||secondref==0
    errordlg('Please analysis the waveform first.And get reference reflection position');
else
    prompt=sprintf('Input the temperature');
    name=sprintf('Value of temperature in ^{o}C');
    numline=1;
    defAns={num2str(20.00)};
    Resize='on';
    target=inputdlg(prompt,name,numline,defAns,'on');
    if(isempty(target))
    else
        if(isempty(target{1}))
        else
            temperature=str2double(target{1});
            
            % water relative permittivity v.s. temperature
            RelativieP=exp(4.474226-4.54426*0.001*temperature);   % water relative permittivity v.s. temperature
    
            timefirst=sampletime*firstref;
            apparefirst=timefirst*vc*vp;
            timesecond=sampletime*secondref;
            apparesecond=timesecond*vc*vp;
            probeL=(apparesecond-apparefirst)/(2*vp*sqrt(RelativieP));
    
            notice=sprintf('The effective probe length is:\n%.2f (mm)\n',probeL);
            select=questdlg(notice,'Effective Probe Length','Select','Default','Select');
            A=(select(1)=='S');
            if A(1)==1
                handles.PROBELENGTHDATA=probeL.*ones(L,1);
                guidata(hObject,handles);        
                % change the probelength
                set(handles.EDIT_PROBE_LENGTH,'string',num2str(handles.PROBELENGTHDATA(index)));
            else
            end
        end
    end
end
    


% --------------------------------------------------------------------
function MENU_RELOAD_Callback(hObject, eventdata, handles)
% hObject    handle to MENU_RELOAD (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

DataFile=sprintf('%s%s',handles.FILEPATH,handles.FILENAME);
ProbeLength=xlsread(DataFile,'sheet2');
handles.PROBELENGTHDATA=ProbeLength;
guidata(hObject, handles);
set(handles.EDIT_PROBE_LENGTH,'string',num2str(handles.PROBELENGTHDATA(handles.WAVEFORMINDEX)));
guidata(hObject, handles);

% --------------------------------------------------------------------
function AUTOSEQ_Callback(hObject, eventdata, handles)
% hObject    handle to AUTOSEQ (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)


% --------------------------------------------------------------------
function FIRSTREF_Callback(hObject, eventdata, handles)
% hObject    handle to FIRSTREF (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)


% --------------------------------------------------------------------
function OPEN_Callback(hObject, eventdata, handles)
% hObject    handle to OPEN (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
 [FileName,PathName]=uigetfile({'*.xlsx';'*.xls';'*.*'},'Select a data file','MultiSelect', 'off');
 if FileName==0
 else
     % clean figures
    Clean_Figures(handles);
    handles.AXES_ORIGINAL_WAVEFORM_ORIGINAL=0;
    handles.AXES_SECOND_BMO_ORIGINAL=0;
    handles.AXES_ORIGINAL_WAVEFORM_SMOOTH=0;
    handles.AXES_SECOND_BMO_SMOOTH=0;
    handles.AXES_ORIGINAL_WAVEFORM_FIRSTREF=0;
    handles.AXES_SECOND_BMO_FIRSTREF=0;
    handles.AXES_ORIGINAL_WAVEFORM_SECREF=0;
    handles.AXES_SECOND_BMO_SECREF=0;
    
    handles.FIRSTREFRES=20;
    handles.SECONDREFRES=40;
    handles.WINDOWLENGTH=0;
    handles.RELATIVEPERMITTIVTY=0;
    handles.VWCTOPP=0;
    handles.MARKED=0;
    guidata(hObject, handles);
    
    DataFile=sprintf('%s%s',PathName,FileName);
    handles.FILENAME=FileName;
    handles.FILEPATH=PathName;
    Waveform=xlsread(DataFile,'sheet1');
    ProbeLength=xlsread(DataFile,'sheet2');
    WindowLength=xlsread(DataFile,'sheet3');
    [L,W]=size(Waveform);
    handles.WAVEFORMDATA=Waveform;
    handles.PROBELENGTHDATA=ProbeLength;
    handles.DATALENGTH=L;
    handles.DATAWIDTH=W;
    handles.WINDOWLENGTH=WindowLength;
    if(isempty(WindowLength))
        set(handles.MENU_WINDOW_LENGTH,'Enable','off');
    else
        set(handles.MENU_WINDOW_LENGTH,'Enable','on');
    end
    guidata(hObject, handles);
    
    % set items
    handles.WAVEFORMINDEX=1;
    set(handles.EDIT_FILENAME,'string',FileName);
    set(handles.EDIT_FILEPATH,'string',PathName);
    set(handles.EDIT_TOTALNUMBER,'string',num2str(L));
    set(handles.EDIT_WAVEFORM_INDEX,'string',num2str(1));
    set(handles.EDIT_PROBE_LENGTH,'string',num2str(handles.PROBELENGTHDATA(1)));
    
    % set sliders
    set(handles.SLIDER_MANUAL_FIRSTREF,'value',((handles.FIRSTREFRES)/(W-1)));
    set(handles.SLIDER_SMOOTH,'value',handles.SMOOTHSTRENGTH);
    set(handles.SLIDER_SENSITIVITY,'value',handles.SENSITIVITYSTRENGTH);
    set(handles.EDIT_MANUAL_FIRSTREF,'string',num2str(handles.FIRSTREFRES));
    set(handles.EDIT_SMOOTH,'string',num2str(handles.SMOOTHSTRENGTH));
    set(handles.EDIT_SENSITIVITY,'string',num2str(handles.SENSITIVITYSTRENGTH));
    guidata(hObject, handles);
    
    % initialize the result vector
    % set result sequence
    handles.MARKED=zeros(L,1);
    handles.FIRSTREFRES=20*ones(L,1);
    handles.SECONDREFRES=zeros(L,1);
    handles.RELATIVEPERMITTIVTY=zeros(L,1);
    handles.VWCTOPP=zeros(L,1);
    guidata(hObject, handles);

    % initialize the first waveform.
    [W1,WBMO,S1,SBMO]=Func_Waveform_Processing(handles);
    handles.TEMPW1=W1;
    handles.TEMPWBMO=WBMO;
    handles.TEMPS1=S1;
    handles.TEMPSBMO=SBMO;
    
    
    HANDLEPLOT=Func_Waveform_Plot(handles,W1,WBMO,S1,SBMO);
    handles.AXES_ORIGINAL_WAVEFORM_ORIGINAL=HANDLEPLOT(1);
    handles.AXES_SECOND_BMO_ORIGINAL=HANDLEPLOT(2);
    handles.AXES_ORIGINAL_WAVEFORM_SMOOTH=HANDLEPLOT(3);
    handles.AXES_SECOND_BMO_SMOOTH=HANDLEPLOT(4);
    guidata(hObject, handles);
 end


% --------------------------------------------------------------------
function SAVE_Callback(hObject, eventdata, handles)
% hObject    handle to SAVE (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
DataFile=sprintf('%s%s',handles.FILEPATH,handles.FILENAME);
vc=handles.LIGHTSPEED;
vp=handles.VELOFRACPROPAGATION;
samplet=handles.SAMPLETIME;
A=handles.FIRSTREFRES;
At=samplet.*handles.FIRSTREFRES;
Ad=At.*vp.*vc;
B=handles.SECONDREFRES;
Bt=samplet.*handles.SECONDREFRES;
Bd=Bt.*vp.*vc;
C=handles.RELATIVEPERMITTIVTY;
D=handles.VWCTOPP;
E=handles.MARKED;

RES=[A At Ad B Bt Bd C D E];
xlswrite(DataFile,RES,'sheet4');



% --------------------------------------------------------------------
function QUIT_Callback(hObject, eventdata, handles)
% hObject    handle to QUIT (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
button=questdlg('Do you want to close?','Close','Yes','No','Yes');
if strcmp(button,'Yes')
    delete(hObject);
    close(gcf);
else
end


% --------------------------------------------------------------------
function MENU_FIRSTREF_SECOND_BMO_Callback(hObject, eventdata, handles)
% hObject    handle to MENU_FIRSTREF_SECOND_BMO (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
set(handles.MENU_FIRSTREF_SECOND_BMO,'checked','on');
set(handles.MENU_FIRSTREF_TANGENT_LINE,'checked','off');
set(handles.MENU_FIRSTREF_TANGENT_HEAP,'checked','off');
set(handles.MENU_FIRSTREF_MANUAL,'checked','off');
set(handles.CHECK_MANUAL_FIRSTREF,'value',0);
handles.FIRSTREFMETHOD=1;
guidata(hObject,handles);

HANDLEPLOT_MANU_FIRREF=Func_Waveform_Plot_FirstManu(handles);
handles.AXES_ORIGINAL_WAVEFORM_FIRSTREF=HANDLEPLOT_MANU_FIRREF(1);
handles.AXES_SECOND_BMO_FIRSTREF=HANDLEPLOT_MANU_FIRREF(2);
guidata(hObject,handles);


% --------------------------------------------------------------------
function MENU_FIRSTREF_TANGENT_LINE_Callback(hObject, eventdata, handles)
% hObject    handle to MENU_FIRSTREF_TANGENT_LINE (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
set(handles.MENU_FIRSTREF_SECOND_BMO,'checked','off');
set(handles.MENU_FIRSTREF_TANGENT_LINE,'checked','on');
set(handles.MENU_FIRSTREF_TANGENT_HEAP,'checked','off');
set(handles.MENU_FIRSTREF_MANUAL,'checked','off');
set(handles.CHECK_MANUAL_FIRSTREF,'value',0);
handles.FIRSTREFMETHOD=2;
guidata(hObject,handles);

HANDLEPLOT_MANU_FIRREF=Func_Waveform_Plot_FirstManu(handles);
handles.AXES_ORIGINAL_WAVEFORM_FIRSTREF=HANDLEPLOT_MANU_FIRREF(1);
handles.AXES_SECOND_BMO_FIRSTREF=HANDLEPLOT_MANU_FIRREF(2);
guidata(hObject,handles);


% --------------------------------------------------------------------
function MENU_FIRSTREF_TANGENT_HEAP_Callback(hObject, eventdata, handles)
% hObject    handle to MENU_FIRSTREF_TANGENT_HEAP (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
set(handles.MENU_FIRSTREF_SECOND_BMO,'checked','off');
set(handles.MENU_FIRSTREF_TANGENT_LINE,'checked','off');
set(handles.MENU_FIRSTREF_TANGENT_HEAP,'checked','on');
set(handles.MENU_FIRSTREF_MANUAL,'checked','off');
set(handles.CHECK_MANUAL_FIRSTREF,'value',0);
handles.FIRSTREFMETHOD=3;
guidata(hObject,handles);

HANDLEPLOT_MANU_FIRREF=Func_Waveform_Plot_FirstManu(handles);
handles.AXES_ORIGINAL_WAVEFORM_FIRSTREF=HANDLEPLOT_MANU_FIRREF(1);
handles.AXES_SECOND_BMO_FIRSTREF=HANDLEPLOT_MANU_FIRREF(2);
guidata(hObject,handles);


% --------------------------------------------------------------------
function MENU_FIRSTREF_MANUAL_Callback(hObject, eventdata, handles)
% hObject    handle to MENU_FIRSTREF_MANUAL (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
set(handles.MENU_FIRSTREF_SECOND_BMO,'checked','off');
set(handles.MENU_FIRSTREF_TANGENT_LINE,'checked','off');
set(handles.MENU_FIRSTREF_TANGENT_HEAP,'checked','off');
set(handles.MENU_FIRSTREF_MANUAL,'checked','on');
set(handles.CHECK_MANUAL_FIRSTREF,'value',1);
handles.FIRSTREFMETHOD=4;
guidata(hObject,handles);

HANDLEPLOT_MANU_FIRREF=Func_Waveform_Plot_FirstManu(handles);
handles.AXES_ORIGINAL_WAVEFORM_FIRSTREF=HANDLEPLOT_MANU_FIRREF(1);
handles.AXES_SECOND_BMO_FIRSTREF=HANDLEPLOT_MANU_FIRREF(2);
guidata(hObject,handles);


% --- Executes on button press in CHECK_MANUAL_FIRSTREF.
function CHECK_MANUAL_FIRSTREF_Callback(hObject, eventdata, handles)
% hObject    handle to CHECK_MANUAL_FIRSTREF (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of CHECK_MANUAL_FIRSTREF
m=get(hObject,'Value');
if m==1
    set(handles.MENU_FIRSTREF_SECOND_BMO,'checked','off');
    set(handles.MENU_FIRSTREF_TANGENT_LINE,'checked','off');
    set(handles.MENU_FIRSTREF_TANGENT_HEAP,'checked','off');
    set(handles.MENU_FIRSTREF_MANUAL,'checked','on');
    handles.FIRSTREFMETHOD=4;
    guidata(hObject,handles);
    
    HANDLEPLOT_MANU_FIRREF=Func_Waveform_Plot_FirstManu(handles);
    handles.AXES_ORIGINAL_WAVEFORM_FIRSTREF=HANDLEPLOT_MANU_FIRREF(1);
    handles.AXES_SECOND_BMO_FIRSTREF=HANDLEPLOT_MANU_FIRREF(2);
    guidata(hObject,handles);
else
    set(handles.MENU_FIRSTREF_SECOND_BMO,'checked','on');
    set(handles.MENU_FIRSTREF_TANGENT_LINE,'checked','off');
    set(handles.MENU_FIRSTREF_TANGENT_HEAP,'checked','off');
    set(handles.MENU_FIRSTREF_MANUAL,'checked','off');
    handles.FIRSTREFMETHOD=1;
    guidata(hObject,handles);
            
    HANDLEPLOT_MANU_FIRREF=Func_Waveform_Plot_FirstManu(handles);
    handles.AXES_ORIGINAL_WAVEFORM_FIRSTREF=HANDLEPLOT_MANU_FIRREF(1);
    handles.AXES_SECOND_BMO_FIRSTREF=HANDLEPLOT_MANU_FIRREF(2);
    guidata(hObject,handles);
end

% --------------------------------------------------------------------
function AUTOSEQ_20_Callback(hObject, eventdata, handles)
% hObject    handle to AUTOSEQ_20 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)


% --------------------------------------------------------------------
function MENU_AUTOSEQ_ALL_Callback(hObject, eventdata, handles)
% hObject    handle to MENU_AUTOSEQ_ALL (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
set(handles.PB_NEXT,'enable','off');
set(handles.PB_PREVIOUS,'enable','off');
set(handles.TOG_MARKED,'enable','off');
set(handles.PB_AUTOMATIC_ANALYSIS,'enable','off');
set(handles.PB_MANUAL_ANALYSIS,'enable','off');

dataLen=handles.DATALENGTH;
index=handles.WAVEFORMINDEX;
vp=handles.VELOFRACPROPAGATION;
sampletime=handles.SAMPLETIME;
vc=handles.LIGHTSPEED;

for i=index:dataLen
    % delete the refs
    if (handles.AXES_ORIGINAL_WAVEFORM_SECREF~=0)
        delete(handles.AXES_ORIGINAL_WAVEFORM_SECREF);
        handles.AXES_ORIGINAL_WAVEFORM_SECREF=0;
    end
    if (handles.AXES_SECOND_BMO_SECREF~=0)
        delete(handles.AXES_SECOND_BMO_SECREF);
        handles.AXES_SECOND_BMO_SECREF=0;
    end
    if(handles.AXES_ORIGINAL_WAVEFORM_FIRSTREF~=0)
        delete(handles.AXES_ORIGINAL_WAVEFORM_FIRSTREF);
        handles.AXES_ORIGINAL_WAVEFORM_FIRSTREF=0;
    end
    if(handles.AXES_SECOND_BMO_FIRSTREF~=0)
        delete(handles.AXES_SECOND_BMO_FIRSTREF);
        handles.AXES_SECOND_BMO_FIRSTREF=0;
    end    
    guidata(hObject,handles);    
    handles.WAVEFORMINDEX=i;
    set(handles.EDIT_WAVEFORM_INDEX,'String',num2str(i));
    guidata(hObject,handles);
    
    % change the probelength
    set(handles.EDIT_PROBE_LENGTH,'string',num2str(handles.PROBELENGTHDATA(i)));

    % redo the plot.
    [W1,WBMO,S1,SBMO]=Func_Waveform_Processing(handles);
    handles.TEMPW1=W1;
    handles.TEMPWBMO=WBMO;
    handles.TEMPS1=S1;
    handles.TEMPSBMO=SBMO;
    
    HANDLEPLOT=Func_Waveform_Plot(handles,W1,WBMO,S1,SBMO);drawnow;
    handles.AXES_ORIGINAL_WAVEFORM_ORIGINAL=HANDLEPLOT(1);
    handles.AXES_SECOND_BMO_ORIGINAL=HANDLEPLOT(2);
    handles.AXES_ORIGINAL_WAVEFORM_SMOOTH=HANDLEPLOT(3);
    handles.AXES_SECOND_BMO_SMOOTH=HANDLEPLOT(4);
    guidata(hObject, handles);
    
    % install manual first ref
    HANDLEPLOT_MANU_FIRREF=Func_Waveform_Plot_FirstManu(handles);
    handles.AXES_ORIGINAL_WAVEFORM_FIRSTREF=HANDLEPLOT_MANU_FIRREF(1);
    handles.AXES_SECOND_BMO_FIRSTREF=HANDLEPLOT_MANU_FIRREF(2);
    guidata(hObject,handles);
    
    % do auto analysis
    probeL=handles.PROBELENGTHDATA(i);

    % first reflection position
    FIRSTREF=Auto_First_Ref_Position(handles);
    handles.FIRSTREFRES(i)=FIRSTREF(1);
    handles.AXES_ORIGINAL_WAVEFORM_FIRSTREF=FIRSTREF(2);
    handles.AXES_SECOND_BMO_FIRSTREF=FIRSTREF(3);
    
    if handles.WINDOWLENGTHTIME==0
        timefirst=sampletime*FIRSTREF(1);
        apparefirst=timefirst*vc*vp;
        Resfirst=sprintf('%f / %f / %f',FIRSTREF(1),timefirst,apparefirst);
        set(handles.EDIT_FIRSTREF_DATA,'String',Resfirst);
    else
        apparefirst=handles.WINDOWLENGTH(index)*FIRSTREF(1)/(handles.DATAWIDTH-1);
        Resfirst=sprintf('%f / NAN / %f',FIRSTREF(1),apparefirst);
        set(handles.EDIT_FIRSTREF_DATA,'String',Resfirst);
    end
    guidata(hObject,handles);

    % second reflection position
    SECONDREF=Auto_Second_Ref_Position(handles);
    handles.SECONDREFRES(i)=SECONDREF(1);
    handles.AXES_ORIGINAL_WAVEFORM_SECREF=SECONDREF(2);
    handles.AXES_SECOND_BMO_SECREF=SECONDREF(3);
    
    if handles.WINDOWLENGTHTIME==0
        timesecond=sampletime*SECONDREF(1);
        apparesecond=timesecond*vc*vp;
        Ressecond=sprintf('%f / %f / %f',SECONDREF(1),timesecond,apparesecond);
        set(handles.EDIT_SECONDREF_DATA,'String',Ressecond);
    else
        apparesecond=handles.WINDOWLENGTH(index)*SECONDREF(1)/(handles.DATAWIDTH-1);
        Ressecond=sprintf('%f / NAN / %f',SECONDREF(1),apparesecond);
        set(handles.EDIT_SECONDREF_DATA,'String',Ressecond);
    end
    guidata(hObject,handles);

    if handles.WINDOWLENGTHTIME==0
        RelativeP=((apparesecond-apparefirst)/(2*vp*probeL))*((apparesecond-apparefirst)/(2*vp*probeL));
    else
        RelativeP=((apparesecond-apparefirst)/probeL)*((apparesecond-apparefirst)/probeL);
    end
    handles.RELATIVEPERMITTIVTY(i)=RelativeP;
    set(handles.EDIT_RPERMITTIVITY,'String',num2str(RelativeP));

    VWC=ToppEq(RelativeP);
    handles.VWCTOPP(i)=VWC;
    set(handles.EDIT_VWC,'String',num2str(VWC));
    guidata(hObject,handles);
end
set(handles.PB_NEXT,'enable','on');
set(handles.PB_PREVIOUS,'enable','on');
set(handles.TOG_MARKED,'enable','on');
set(handles.PB_AUTOMATIC_ANALYSIS,'enable','on');
set(handles.PB_MANUAL_ANALYSIS,'enable','on');

% --------------------------------------------------------------------
function MENU_AUTOSEQ_ARBITRARY_Callback(hObject, eventdata, handles)
% hObject    handle to MENU_AUTOSEQ_ARBITRARY (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
prompt=sprintf('Input the number of waveforms you want to go ahead.(Should be an integer)');
name=sprintf('Number of Waveforms');
numline=1;
defAns={num2str('1')};
Resize='on';
target=inputdlg(prompt,name,numline,defAns,'on');
if(isempty(target))
else
    if(isempty(target{1}))
    else
        L=floor(str2double(target{1}));
    end
end

set(handles.PB_NEXT,'enable','off');
set(handles.PB_PREVIOUS,'enable','off');
set(handles.TOG_MARKED,'enable','off');
set(handles.PB_AUTOMATIC_ANALYSIS,'enable','off');
set(handles.PB_MANUAL_ANALYSIS,'enable','off');

dataLen=handles.DATALENGTH;
index=handles.WAVEFORMINDEX;
vp=handles.VELOFRACPROPAGATION;
sampletime=handles.SAMPLETIME;
vc=handles.LIGHTSPEED;

if index+L-1>dataLen
    errordlg('Number requested exceeds the range.')
else
    for i=index:index+L-1
        % delete the refs
        if (handles.AXES_ORIGINAL_WAVEFORM_SECREF~=0)
            delete(handles.AXES_ORIGINAL_WAVEFORM_SECREF);
            handles.AXES_ORIGINAL_WAVEFORM_SECREF=0;
        end
        if (handles.AXES_SECOND_BMO_SECREF~=0)
            delete(handles.AXES_SECOND_BMO_SECREF);
            handles.AXES_SECOND_BMO_SECREF=0;
        end
        if(handles.AXES_ORIGINAL_WAVEFORM_FIRSTREF~=0)
            delete(handles.AXES_ORIGINAL_WAVEFORM_FIRSTREF);
            handles.AXES_ORIGINAL_WAVEFORM_FIRSTREF=0;
        end
        if(handles.AXES_SECOND_BMO_FIRSTREF~=0)
            delete(handles.AXES_SECOND_BMO_FIRSTREF);
            handles.AXES_SECOND_BMO_FIRSTREF=0;
        end    
        guidata(hObject,handles);    
        handles.WAVEFORMINDEX=i;
        set(handles.EDIT_WAVEFORM_INDEX,'String',num2str(i));
        guidata(hObject,handles);

        % change the probelength
        set(handles.EDIT_PROBE_LENGTH,'string',num2str(handles.PROBELENGTHDATA(i)));

        % redo the plot.
        [W1,WBMO,S1,SBMO]=Func_Waveform_Processing(handles);
        handles.TEMPW1=W1;
        handles.TEMPWBMO=WBMO;
        handles.TEMPS1=S1;
        handles.TEMPSBMO=SBMO;

        HANDLEPLOT=Func_Waveform_Plot(handles,W1,WBMO,S1,SBMO);drawnow;
        handles.AXES_ORIGINAL_WAVEFORM_ORIGINAL=HANDLEPLOT(1);
        handles.AXES_SECOND_BMO_ORIGINAL=HANDLEPLOT(2);
        handles.AXES_ORIGINAL_WAVEFORM_SMOOTH=HANDLEPLOT(3);
        handles.AXES_SECOND_BMO_SMOOTH=HANDLEPLOT(4);
        guidata(hObject, handles);

        % install manual first ref
        HANDLEPLOT_MANU_FIRREF=Func_Waveform_Plot_FirstManu(handles);
        handles.AXES_ORIGINAL_WAVEFORM_FIRSTREF=HANDLEPLOT_MANU_FIRREF(1);
        handles.AXES_SECOND_BMO_FIRSTREF=HANDLEPLOT_MANU_FIRREF(2);
        guidata(hObject,handles);

        % do auto analysis
        probeL=handles.PROBELENGTHDATA(i);

        % first reflection position
        FIRSTREF=Auto_First_Ref_Position(handles);
        handles.FIRSTREFRES(i)=FIRSTREF(1);
        handles.AXES_ORIGINAL_WAVEFORM_FIRSTREF=FIRSTREF(2);
        handles.AXES_SECOND_BMO_FIRSTREF=FIRSTREF(3);
        
        if handles.WINDOWLENGTHTIME==0
            timefirst=sampletime*FIRSTREF(1);
            apparefirst=timefirst*vc*vp;
            Resfirst=sprintf('%f / %f / %f',FIRSTREF(1),timefirst,apparefirst);
            set(handles.EDIT_FIRSTREF_DATA,'String',Resfirst);
        else
            apparefirst=handles.WINDOWLENGTH(index)*FIRSTREF(1)/(handles.DATAWIDTH-1);
            Resfirst=sprintf('%f / NAN / %f',FIRSTREF(1),apparefirst);
            set(handles.EDIT_FIRSTREF_DATA,'String',Resfirst);
        end
        guidata(hObject,handles);

        % second reflection position
        SECONDREF=Auto_Second_Ref_Position(handles);
        handles.SECONDREFRES(i)=SECONDREF(1);
        handles.AXES_ORIGINAL_WAVEFORM_SECREF=SECONDREF(2);
        handles.AXES_SECOND_BMO_SECREF=SECONDREF(3);
        
        if handles.WINDOWLENGTHTIME==0
            timesecond=sampletime*SECONDREF(1);
            apparesecond=timesecond*vc*vp;
            Ressecond=sprintf('%f / %f / %f',SECONDREF(1),timesecond,apparesecond);
            set(handles.EDIT_SECONDREF_DATA,'String',Ressecond);
        else
            apparesecond=handles.WINDOWLENGTH(index)*SECONDREF(1)/(handles.DATAWIDTH-1);
            Ressecond=sprintf('%f / NAN / %f',SECONDREF(1),apparesecond);
            set(handles.EDIT_SECONDREF_DATA,'String',Ressecond);
        end
        guidata(hObject,handles);

        if handles.WINDOWLENGTHTIME==0
            RelativeP=((apparesecond-apparefirst)/(2*vp*probeL))*((apparesecond-apparefirst)/(2*vp*probeL));
        else
            RelativeP=((apparesecond-apparefirst)/probeL)*((apparesecond-apparefirst)/probeL);
        end
        handles.RELATIVEPERMITTIVTY(i)=RelativeP;
        set(handles.EDIT_RPERMITTIVITY,'String',num2str(RelativeP));

        VWC=ToppEq(RelativeP);
        handles.VWCTOPP(i)=VWC;
        set(handles.EDIT_VWC,'String',num2str(VWC));
        guidata(hObject,handles);
    end
end
set(handles.PB_NEXT,'enable','on');
set(handles.PB_PREVIOUS,'enable','on');
set(handles.TOG_MARKED,'enable','on');
set(handles.PB_AUTOMATIC_ANALYSIS,'enable','on');
set(handles.PB_MANUAL_ANALYSIS,'enable','on');


function EDIT_FILENAME_Callback(hObject, eventdata, handles)
% hObject    handle to EDIT_FILENAME (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of EDIT_FILENAME as text
%        str2double(get(hObject,'String')) returns contents of EDIT_FILENAME as a double


% --- Executes during object creation, after setting all properties.
function EDIT_FILENAME_CreateFcn(hObject, eventdata, handles)
% hObject    handle to EDIT_FILENAME (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function EDIT_FILEPATH_Callback(hObject, eventdata, handles)
% hObject    handle to EDIT_FILEPATH (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of EDIT_FILEPATH as text
%        str2double(get(hObject,'String')) returns contents of EDIT_FILEPATH as a double


% --- Executes during object creation, after setting all properties.
function EDIT_FILEPATH_CreateFcn(hObject, eventdata, handles)
% hObject    handle to EDIT_FILEPATH (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function EDIT_FIRSTREF_DATA_Callback(hObject, eventdata, handles)
% hObject    handle to EDIT_FIRSTREF_DATA (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of EDIT_FIRSTREF_DATA as text
%        str2double(get(hObject,'String')) returns contents of EDIT_FIRSTREF_DATA as a double


% --- Executes during object creation, after setting all properties.
function EDIT_FIRSTREF_DATA_CreateFcn(hObject, eventdata, handles)
% hObject    handle to EDIT_FIRSTREF_DATA (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function EDIT_SECONDREF_DATA_Callback(hObject, eventdata, handles)
% hObject    handle to EDIT_SECONDREF_DATA (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of EDIT_SECONDREF_DATA as text
%        str2double(get(hObject,'String')) returns contents of EDIT_SECONDREF_DATA as a double


% --- Executes during object creation, after setting all properties.
function EDIT_SECONDREF_DATA_CreateFcn(hObject, eventdata, handles)
% hObject    handle to EDIT_SECONDREF_DATA (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function EDIT_RPERMITTIVITY_Callback(hObject, eventdata, handles)
% hObject    handle to EDIT_RPERMITTIVITY (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of EDIT_RPERMITTIVITY as text
%        str2double(get(hObject,'String')) returns contents of EDIT_RPERMITTIVITY as a double


% --- Executes during object creation, after setting all properties.
function EDIT_RPERMITTIVITY_CreateFcn(hObject, eventdata, handles)
% hObject    handle to EDIT_RPERMITTIVITY (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function EDIT_VWC_Callback(hObject, eventdata, handles)
% hObject    handle to EDIT_VWC (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of EDIT_VWC as text
%        str2double(get(hObject,'String')) returns contents of EDIT_VWC as a double


% --- Executes during object creation, after setting all properties.
function EDIT_VWC_CreateFcn(hObject, eventdata, handles)
% hObject    handle to EDIT_VWC (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in PB_MANUAL_ANALYSIS.
function PB_MANUAL_ANALYSIS_Callback(hObject, eventdata, handles)
% hObject    handle to PB_MANUAL_ANALYSIS (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% note the parameters
index=handles.WAVEFORMINDEX;
vp=handles.VELOFRACPROPAGATION;
sampletime=handles.SAMPLETIME;
vc=handles.LIGHTSPEED;
probeL=handles.PROBELENGTHDATA(index);

% first reflection position
FIRSTREF=Manual_First_Ref_Position(handles);
handles.FIRSTREFRES(index)=FIRSTREF(1);
handles.AXES_ORIGINAL_WAVEFORM_FIRSTREF=FIRSTREF(2);
handles.AXES_SECOND_BMO_FIRSTREF=FIRSTREF(3);

if handles.WINDOWLENGTHTIME==0
    timefirst=sampletime*FIRSTREF(1);
    apparefirst=timefirst*vc*vp;
    Resfirst=sprintf('%f / %f / %f',FIRSTREF(1),timefirst,apparefirst);
    set(handles.EDIT_FIRSTREF_DATA,'String',Resfirst);
else
    apparefirst=handles.WINDOWLENGTH(index)*FIRSTREF(1)/(handles.DATAWIDTH-1);
    Resfirst=sprintf('%f / NAN / %f',FIRSTREF(1),apparefirst);
    set(handles.EDIT_FIRSTREF_DATA,'String',Resfirst);
end
guidata(hObject,handles);

% second reflection position
SECONDREF=Manual_Second_Ref_Position(handles);
handles.SECONDREFRES(index)=SECONDREF(1);
handles.AXES_ORIGINAL_WAVEFORM_SECREF=SECONDREF(2);
handles.AXES_SECOND_BMO_SECREF=SECONDREF(3);

if handles.WINDOWLENGTHTIME==0
    timesecond=sampletime*SECONDREF(1);
    apparesecond=timesecond*vc*vp;
    Ressecond=sprintf('%f / %f / %f',SECONDREF(1),timesecond,apparesecond);
    set(handles.EDIT_SECONDREF_DATA,'String',Ressecond);
else
    apparesecond=handles.WINDOWLENGTH(index)*SECONDREF(1)/(handles.DATAWIDTH-1);
    Ressecond=sprintf('%f / NAN / %f',SECONDREF(1),apparesecond);
    set(handles.EDIT_SECONDREF_DATA,'String',Ressecond);
end
guidata(hObject,handles);

if handles.WINDOWLENGTHTIME==0
    RelativeP=((apparesecond-apparefirst)/(2*vp*probeL))*((apparesecond-apparefirst)/(2*vp*probeL));
else
    RelativeP=((apparesecond-apparefirst)/probeL)*((apparesecond-apparefirst)/probeL);
end
handles.RELATIVEPERMITTIVTY(index)=RelativeP;
set(handles.EDIT_RPERMITTIVITY,'String',num2str(RelativeP));

VWC=ToppEq(RelativeP);
handles.VWCTOPP(index)=VWC;
set(handles.EDIT_VWC,'String',num2str(VWC));
guidata(hObject,handles);

% --- Executes on button press in PB_AUTOMATIC_ANALYSIS.
function PB_AUTOMATIC_ANALYSIS_Callback(hObject, eventdata, handles)
% hObject    handle to PB_AUTOMATIC_ANALYSIS (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% note the parameters
index=handles.WAVEFORMINDEX;
vp=handles.VELOFRACPROPAGATION;
sampletime=handles.SAMPLETIME;
vc=handles.LIGHTSPEED;
probeL=handles.PROBELENGTHDATA(index);

% first reflection position
FIRSTREF=Auto_First_Ref_Position(handles);
handles.FIRSTREFRES(index)=FIRSTREF(1);
handles.AXES_ORIGINAL_WAVEFORM_FIRSTREF=FIRSTREF(2);
handles.AXES_SECOND_BMO_FIRSTREF=FIRSTREF(3);

if handles.WINDOWLENGTHTIME==0
    timefirst=sampletime*FIRSTREF(1);
    apparefirst=timefirst*vc*vp;
    Resfirst=sprintf('%f / %f / %f',FIRSTREF(1),timefirst,apparefirst);
    set(handles.EDIT_FIRSTREF_DATA,'String',Resfirst);
else
    apparefirst=handles.WINDOWLENGTH(index)*FIRSTREF(1)/(handles.DATAWIDTH-1);
    Resfirst=sprintf('%f / NAN / %f',FIRSTREF(1),apparefirst);
    set(handles.EDIT_FIRSTREF_DATA,'String',Resfirst);
end
guidata(hObject,handles);

% second reflection position
SECONDREF=Auto_Second_Ref_Position(handles);
handles.SECONDREFRES(index)=SECONDREF(1);
handles.AXES_ORIGINAL_WAVEFORM_SECREF=SECONDREF(2);
handles.AXES_SECOND_BMO_SECREF=SECONDREF(3);

if handles.WINDOWLENGTHTIME==0
    timesecond=sampletime*SECONDREF(1);
    apparesecond=timesecond*vc*vp;
    Ressecond=sprintf('%f / %f / %f',SECONDREF(1),timesecond,apparesecond);
    set(handles.EDIT_SECONDREF_DATA,'String',Ressecond);
else
    apparesecond=handles.WINDOWLENGTH(index)*SECONDREF(1)/(handles.DATAWIDTH-1);
    Ressecond=sprintf('%f / NAN / %f',SECONDREF(1),apparesecond);
    set(handles.EDIT_SECONDREF_DATA,'String',Ressecond);
end
guidata(hObject,handles);

if handles.WINDOWLENGTHTIME==0
    RelativeP=((apparesecond-apparefirst)/(2*vp*probeL))*((apparesecond-apparefirst)/(2*vp*probeL));
else
    RelativeP=((apparesecond-apparefirst)/probeL)*((apparesecond-apparefirst)/probeL);
end
handles.RELATIVEPERMITTIVTY(index)=RelativeP;
set(handles.EDIT_RPERMITTIVITY,'String',num2str(RelativeP));

VWC=ToppEq(RelativeP);
handles.VWCTOPP(index)=VWC;
set(handles.EDIT_VWC,'String',num2str(VWC));
guidata(hObject,handles);


function EDIT_WAVEFORM_INDEX_Callback(hObject, eventdata, handles)
% hObject    handle to EDIT_WAVEFORM_INDEX (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of EDIT_WAVEFORM_INDEX as text
%        str2double(get(hObject,'String')) returns contents of EDIT_WAVEFORM_INDEX as a double
m=str2double(get(hObject,'String'));

if m<1
    set(hObject,'String',num2str(handles.WAVEFORMINDEX));
    errordlg('It is the first waveform');
elseif m>handles.DATALENGTH
    set(hObject,'String',num2str(handles.WAVEFORMINDEX));
    errordlg('It is the last waveform');
else
    
    % delete the previous reflection
    if (handles.AXES_ORIGINAL_WAVEFORM_SECREF~=0)
        delete(handles.AXES_ORIGINAL_WAVEFORM_SECREF);
        handles.AXES_ORIGINAL_WAVEFORM_SECREF=0;
    end
    if (handles.AXES_SECOND_BMO_SECREF~=0)
        delete(handles.AXES_SECOND_BMO_SECREF);
        handles.AXES_SECOND_BMO_SECREF=0;
    end
    if(handles.AXES_ORIGINAL_WAVEFORM_FIRSTREF~=0)
        delete(handles.AXES_ORIGINAL_WAVEFORM_FIRSTREF);
        handles.AXES_ORIGINAL_WAVEFORM_FIRSTREF=0;
    end
    if(handles.AXES_SECOND_BMO_FIRSTREF~=0)
        delete(handles.AXES_SECOND_BMO_FIRSTREF);
        handles.AXES_SECOND_BMO_FIRSTREF=0;
    end
        
    handles.WAVEFORMINDEX=m;
    guidata(hObject,handles);
        
    % empty something
    set(handles.TOG_MARKED,'value',0);
    % change the probelength
    set(handles.EDIT_PROBE_LENGTH,'string',num2str(handles.PROBELENGTHDATA(m)));
    
    % redo the plot.
    [W1,WBMO,S1,SBMO]=Func_Waveform_Processing(handles);
    handles.TEMPW1=W1;
    handles.TEMPWBMO=WBMO;
    handles.TEMPS1=S1;
    handles.TEMPSBMO=SBMO;
        
    if(handles.AXES_ORIGINAL_WAVEFORM_ORIGINAL~=0)
        delete(handles.AXES_ORIGINAL_WAVEFORM_ORIGINAL);
        handles.AXES_ORIGINAL_WAVEFORM_ORIGINAL=0;
    end
    if(handles.AXES_SECOND_BMO_ORIGINAL~=0)
        delete(handles.AXES_SECOND_BMO_ORIGINAL);
        handles.AXES_SECOND_BMO_ORIGINAL=0;
    end
    if(handles.AXES_ORIGINAL_WAVEFORM_SMOOTH~=0)
        delete(handles.AXES_ORIGINAL_WAVEFORM_SMOOTH);
        handles.AXES_ORIGINAL_WAVEFORM_SMOOTH=0;
    end
    if(handles.AXES_SECOND_BMO_SMOOTH~=0)
        delete(handles.AXES_SECOND_BMO_SMOOTH);
        handles.AXES_SECOND_BMO_SMOOTH=0;
    end
    guidata(hObject, handles);
    
    HANDLEPLOT=Func_Waveform_Plot(handles,W1,WBMO,S1,SBMO);
    handles.AXES_ORIGINAL_WAVEFORM_ORIGINAL=HANDLEPLOT(1);
    handles.AXES_SECOND_BMO_ORIGINAL=HANDLEPLOT(2);
    handles.AXES_ORIGINAL_WAVEFORM_SMOOTH=HANDLEPLOT(3);
    handles.AXES_SECOND_BMO_SMOOTH=HANDLEPLOT(4);
    guidata(hObject, handles);
    
    % install manual first ref
    HANDLEPLOT_MANU_FIRREF=Func_Waveform_Plot_FirstManu(handles);
    handles.AXES_ORIGINAL_WAVEFORM_FIRSTREF=HANDLEPLOT_MANU_FIRREF(1);
    handles.AXES_SECOND_BMO_FIRSTREF=HANDLEPLOT_MANU_FIRREF(2);
    guidata(hObject,handles);
end


% --- Executes during object creation, after setting all properties.
function EDIT_WAVEFORM_INDEX_CreateFcn(hObject, eventdata, handles)
% hObject    handle to EDIT_WAVEFORM_INDEX (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


function EDIT_MANUAL_FIRSTREF_Callback(hObject, eventdata, handles)
% hObject    handle to EDIT_MANUAL_FIRSTREF (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of EDIT_MANUAL_FIRSTREF as text
%        str2double(get(hObject,'String')) returns contents of EDIT_MANUAL_FIRSTREF as a double
m=str2double(get(hObject,'String'));
W=handles.DATAWIDTH;
set(handles.SLIDER_MANUAL_FIRSTREF,'value',(m/(W-1)));
guidata(hObject,handles);

HANDLEPLOT_MANU_FIRREF=Func_Waveform_Plot_FirstManu(handles);
handles.AXES_ORIGINAL_WAVEFORM_FIRSTREF=HANDLEPLOT_MANU_FIRREF(1);
handles.AXES_SECOND_BMO_FIRSTREF=HANDLEPLOT_MANU_FIRREF(2);
guidata(hObject,handles);

% --- Executes during object creation, after setting all properties.
function EDIT_MANUAL_FIRSTREF_CreateFcn(hObject, eventdata, handles)
% hObject    handle to EDIT_MANUAL_FIRSTREF (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

% --- Executes on slider movement.
function SLIDER_MANUAL_FIRSTREF_Callback(hObject, eventdata, handles)
% hObject    handle to SLIDER_MANUAL_FIRSTREF (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'Value') returns position of slider
%        get(hObject,'Min') and get(hObject,'Max') to determine range of slider
m=get(hObject,'Value');
W=handles.DATAWIDTH;
set(handles.EDIT_MANUAL_FIRSTREF,'string',num2str((W-1)*m));
guidata(hObject,handles);

HANDLEPLOT_MANU_FIRREF=Func_Waveform_Plot_FirstManu(handles);
handles.AXES_ORIGINAL_WAVEFORM_FIRSTREF=HANDLEPLOT_MANU_FIRREF(1);
handles.AXES_SECOND_BMO_FIRSTREF=HANDLEPLOT_MANU_FIRREF(2);
guidata(hObject,handles);

% --- Executes during object creation, after setting all properties.
function SLIDER_MANUAL_FIRSTREF_CreateFcn(hObject, eventdata, handles)
% hObject    handle to SLIDER_MANUAL_FIRSTREF (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: slider controls usually have a light gray background.
if isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor',[.9 .9 .9]);
end

% --- Executes on button press in CHECK_SMOOTH.
function CHECK_SMOOTH_Callback(hObject, eventdata, handles)
% hObject    handle to CHECK_SMOOTH (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of CHECK_SMOOTH
m=get(hObject,'Value');
handles.CHECK_SMOOTH=m;
guidata(hObject, handles);

% redo the plot
[W1,WBMO,S1,SBMO]=Func_Waveform_Processing(handles);
handles.TEMPW1=W1;
handles.TEMPWBMO=WBMO;
handles.TEMPS1=S1;
handles.TEMPSBMO=SBMO;
HANDLEPLOT=Func_Waveform_Plot(handles,W1,WBMO,S1,SBMO);
handles.AXES_ORIGINAL_WAVEFORM_ORIGINAL=HANDLEPLOT(1);
handles.AXES_SECOND_BMO_ORIGINAL=HANDLEPLOT(2);
handles.AXES_ORIGINAL_WAVEFORM_SMOOTH=HANDLEPLOT(3);
handles.AXES_SECOND_BMO_SMOOTH=HANDLEPLOT(4);
guidata(hObject, handles);

% --- Executes on slider movement.
function SLIDER_SMOOTH_Callback(hObject, eventdata, handles)
% hObject    handle to SLIDER_SMOOTH (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'Value') returns position of slider
%        get(hObject,'Min') and get(hObject,'Max') to determine range of slider
m=get(hObject,'Value');
set(handles.EDIT_SMOOTH,'string',num2str(m));
handles.SMOOTHSTRENGTH=m;
guidata(hObject, handles);

% redo the plot
if handles.CHECK_SMOOTH==1;
    [W1,WBMO,S1,SBMO]=Func_Waveform_Processing(handles);
    handles.TEMPW1=W1;
    handles.TEMPWBMO=WBMO;
    handles.TEMPS1=S1;
    handles.TEMPSBMO=SBMO;
    
    HANDLEPLOT=Func_Waveform_Plot(handles,W1,WBMO,S1,SBMO);
    handles.AXES_ORIGINAL_WAVEFORM_ORIGINAL=HANDLEPLOT(1);
    handles.AXES_SECOND_BMO_ORIGINAL=HANDLEPLOT(2);
    handles.AXES_ORIGINAL_WAVEFORM_SMOOTH=HANDLEPLOT(3);
    handles.AXES_SECOND_BMO_SMOOTH=HANDLEPLOT(4);
    guidata(hObject, handles);
else
end

% --- Executes during object creation, after setting all properties.
function SLIDER_SMOOTH_CreateFcn(hObject, eventdata, handles)
% hObject    handle to SLIDER_SMOOTH (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: slider controls usually have a light gray background.
if isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor',[.9 .9 .9]);
end

function EDIT_SMOOTH_Callback(hObject, eventdata, handles)
% hObject    handle to EDIT_SMOOTH (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of EDIT_SMOOTH as text
%        str2double(get(hObject,'String')) returns contents of EDIT_SMOOTH as a double
m=str2num(get(hObject,'String'));
set(handles.SLIDER_SMOOTH,'value',m);
handles.SMOOTHSTRENGTH=m;
guidata(hObject, handles);

% redo the plot
if handles.CHECK_SMOOTH==1;
    [W1,WBMO,S1,SBMO]=Func_Waveform_Processing(handles);
    handles.TEMPW1=W1;
    handles.TEMPWBMO=WBMO;
    handles.TEMPS1=S1;
    handles.TEMPSBMO=SBMO;
    
    HANDLEPLOT=Func_Waveform_Plot(handles,W1,WBMO,S1,SBMO);
    handles.AXES_ORIGINAL_WAVEFORM_ORIGINAL=HANDLEPLOT(1);
    handles.AXES_SECOND_BMO_ORIGINAL=HANDLEPLOT(2);
    handles.AXES_ORIGINAL_WAVEFORM_SMOOTH=HANDLEPLOT(3);
    handles.AXES_SECOND_BMO_SMOOTH=HANDLEPLOT(4);
    guidata(hObject, handles);
else
end

% --- Executes during object creation, after setting all properties.
function EDIT_SMOOTH_CreateFcn(hObject, eventdata, handles)
% hObject    handle to EDIT_SMOOTH (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

function EDIT_SENSITIVITY_Callback(hObject, eventdata, handles)
% hObject    handle to EDIT_SENSITIVITY (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of EDIT_SENSITIVITY as text
%        str2double(get(hObject,'String')) returns contents of EDIT_SENSITIVITY as a double
m=str2num(get(hObject,'String'));
set(handles.SLIDER_SENSITIVITY,'value',m);
handles.SENSITIVITYSTRENGTH=m;
guidata(hObject, handles);

% --- Executes during object creation, after setting all properties.
function EDIT_SENSITIVITY_CreateFcn(hObject, eventdata, handles)
% hObject    handle to EDIT_SENSITIVITY (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

% --- Executes on slider movement.
function SLIDER_SENSITIVITY_Callback(hObject, eventdata, handles)
% hObject    handle to SLIDER_SENSITIVITY (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'Value') returns position of slider
%        get(hObject,'Min') and get(hObject,'Max') to determine range of slider
m=get(hObject,'Value');
set(handles.EDIT_SENSITIVITY,'string',m);
handles.SENSITIVITYSTRENGTH=m;
guidata(hObject, handles);

% --- Executes during object creation, after setting all properties.
function SLIDER_SENSITIVITY_CreateFcn(hObject, eventdata, handles)
% hObject    handle to SLIDER_SENSITIVITY (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: slider controls usually have a light gray background.
if isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor',[.9 .9 .9]);
end

% --- Executes on button press in PB_PREVIOUS.
function PB_PREVIOUS_Callback(hObject, eventdata, handles)
% hObject    handle to PB_PREVIOUS (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
set(handles.PB_PREVIOUS,'enable','off');
m=handles.WAVEFORMINDEX;

if m==1
    errordlg('It is the first waveform');
else
    % delete the refs
    if (handles.AXES_ORIGINAL_WAVEFORM_SECREF~=0)
        delete(handles.AXES_ORIGINAL_WAVEFORM_SECREF);
        handles.AXES_ORIGINAL_WAVEFORM_SECREF=0;
    end
    if (handles.AXES_SECOND_BMO_SECREF~=0)
        delete(handles.AXES_SECOND_BMO_SECREF);
        handles.AXES_SECOND_BMO_SECREF=0;
    end
    if(handles.AXES_ORIGINAL_WAVEFORM_FIRSTREF~=0)
        delete(handles.AXES_ORIGINAL_WAVEFORM_FIRSTREF);
        handles.AXES_ORIGINAL_WAVEFORM_FIRSTREF=0;
    end
    if(handles.AXES_SECOND_BMO_FIRSTREF~=0)
        delete(handles.AXES_SECOND_BMO_FIRSTREF);
        handles.AXES_SECOND_BMO_FIRSTREF=0;
    end
       
    guidata(hObject,handles);
    
    handles.WAVEFORMINDEX=m-1;
    set(handles.EDIT_WAVEFORM_INDEX,'String',num2str(m-1));
    guidata(hObject,handles);
    
    % empty something
    set(handles.TOG_MARKED,'value',0);
    % change the probelength
    set(handles.EDIT_PROBE_LENGTH,'string',num2str(handles.PROBELENGTHDATA(m-1)));
    
    % redo the plot.
    [W1,WBMO,S1,SBMO]=Func_Waveform_Processing(handles);
    handles.TEMPW1=W1;
    handles.TEMPWBMO=WBMO;
    handles.TEMPS1=S1;
    handles.TEMPSBMO=SBMO;    
    HANDLEPLOT=Func_Waveform_Plot(handles,W1,WBMO,S1,SBMO);drawnow;
    handles.AXES_ORIGINAL_WAVEFORM_ORIGINAL=HANDLEPLOT(1);
    handles.AXES_SECOND_BMO_ORIGINAL=HANDLEPLOT(2);
    handles.AXES_ORIGINAL_WAVEFORM_SMOOTH=HANDLEPLOT(3);
    handles.AXES_SECOND_BMO_SMOOTH=HANDLEPLOT(4);
    guidata(hObject, handles);
    
    % install manual first ref
    HANDLEPLOT_MANU_FIRREF=Func_Waveform_Plot_FirstManu(handles);
    handles.AXES_ORIGINAL_WAVEFORM_FIRSTREF=HANDLEPLOT_MANU_FIRREF(1);
    handles.AXES_SECOND_BMO_FIRSTREF=HANDLEPLOT_MANU_FIRREF(2);
    guidata(hObject,handles);
    
end
set(handles.PB_PREVIOUS,'enable','on');

% --- Executes on button press in PB_NEXT.
function PB_NEXT_Callback(hObject, eventdata, handles)
% hObject    handle to PB_NEXT (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
set(handles.PB_NEXT,'enable','off');
m=handles.WAVEFORMINDEX;

if m==handles.DATALENGTH
    errordlg('It is the last waveform');
else
    % delete the second refs
    if (handles.AXES_ORIGINAL_WAVEFORM_SECREF~=0)
        delete(handles.AXES_ORIGINAL_WAVEFORM_SECREF);
        handles.AXES_ORIGINAL_WAVEFORM_SECREF=0;
    end
    if (handles.AXES_SECOND_BMO_SECREF~=0)
        delete(handles.AXES_SECOND_BMO_SECREF);
        handles.AXES_SECOND_BMO_SECREF=0;
    end
    if(handles.AXES_ORIGINAL_WAVEFORM_FIRSTREF~=0)
        delete(handles.AXES_ORIGINAL_WAVEFORM_FIRSTREF);
        handles.AXES_ORIGINAL_WAVEFORM_FIRSTREF=0;
    end
    if(handles.AXES_SECOND_BMO_FIRSTREF~=0)
        delete(handles.AXES_SECOND_BMO_FIRSTREF);
        handles.AXES_SECOND_BMO_FIRSTREF=0;
    end
    
    guidata(hObject,handles);
    
    handles.WAVEFORMINDEX=m+1;
    set(handles.EDIT_WAVEFORM_INDEX,'String',num2str(m+1));
    guidata(hObject,handles);
    
    % empty something
    set(handles.TOG_MARKED,'value',0);
    % change the probelength
    set(handles.EDIT_PROBE_LENGTH,'string',num2str(handles.PROBELENGTHDATA(m+1)));

    % redo the plot.
    [W1,WBMO,S1,SBMO]=Func_Waveform_Processing(handles);
    handles.TEMPW1=W1;
    handles.TEMPWBMO=WBMO;
    handles.TEMPS1=S1;
    handles.TEMPSBMO=SBMO;
    
    HANDLEPLOT=Func_Waveform_Plot(handles,W1,WBMO,S1,SBMO);drawnow;
    handles.AXES_ORIGINAL_WAVEFORM_ORIGINAL=HANDLEPLOT(1);
    handles.AXES_SECOND_BMO_ORIGINAL=HANDLEPLOT(2);
    handles.AXES_ORIGINAL_WAVEFORM_SMOOTH=HANDLEPLOT(3);
    handles.AXES_SECOND_BMO_SMOOTH=HANDLEPLOT(4);
    guidata(hObject, handles);
    
    % install manual first ref
    HANDLEPLOT_MANU_FIRREF=Func_Waveform_Plot_FirstManu(handles);
    handles.AXES_ORIGINAL_WAVEFORM_FIRSTREF=HANDLEPLOT_MANU_FIRREF(1);
    handles.AXES_SECOND_BMO_FIRSTREF=HANDLEPLOT_MANU_FIRREF(2);
    guidata(hObject,handles);
end
set(handles.PB_NEXT,'enable','on');

% --- Executes on button press in TOG_MARKED.
function TOG_MARKED_Callback(hObject, eventdata, handles)
% hObject    handle to TOG_MARKED (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of TOG_MARKED
mark=get(hObject,'Value');
index=handles.WAVEFORMINDEX;
handles.MARKED(index)=mark;
guidata(hObject, handles);


% --------------------------------------------------------------------
function PROP_SETTING_Callback(hObject, eventdata, handles)
% hObject    handle to MENU_SAMPLING_TIME (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% --------------------------------------------------------------------
function MENU_VELOCITY_FRAC_OF_PROPAGATION_Callback(hObject, eventdata, handles)
% hObject    handle to MENU_VELOCITY_FRAC_OF_PROPAGATION (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
prompt=sprintf('Input the velocity fraction of propagation');
name=sprintf('Value of velocity fraction of propagation (V_p) of your probe');
numline=1;
defAns={num2str(handles.VELOFRACPROPAGATION)};
Resize='on';
target=inputdlg(prompt,name,numline,defAns,'on');
if(isempty(target))
else
    if(isempty(target{1}))
    else
        handles.VELOFRACPROPAGATION=str2double(target{1});
        guidata(hObject, handles);
    end
end

% --------------------------------------------------------------------
function MENU_SAMPLING_TIME_Callback(hObject, eventdata, handles)
% hObject    handle to MENU_SAMPLING_TIME (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
set(handles.MENU_SAMPLING_TIME,'checked','on');
set(handles.MENU_WINDOW_LENGTH,'checked','off');
handles.WINDOWLENGTHTIME=0;
prompt=sprintf('Input the sampling time');
name=sprintf('Value of time between two sampling point');
numline=1;
defAns={num2str(handles.SAMPLETIME)};
Resize='on';
target=inputdlg(prompt,name,numline,defAns,'on');
if(isempty(target))
else
    if(isempty(target{1}))
    else
        handles.SAMPLETIME=str2double(target{1});
        guidata(hObject, handles);
    end
end


function EDIT_TOTALNUMBER_Callback(hObject, eventdata, handles)
% hObject    handle to EDIT_TOTALNUMBER (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of EDIT_TOTALNUMBER as text
%        str2double(get(hObject,'String')) returns contents of EDIT_TOTALNUMBER as a double
set(hObject,'String',num2str(handles.DATALENGTH))


% --- Executes during object creation, after setting all properties.
function EDIT_TOTALNUMBER_CreateFcn(hObject, eventdata, handles)
% hObject    handle to EDIT_TOTALNUMBER (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

function EDIT_PROBE_LENGTH_Callback(hObject, eventdata, handles)
% hObject    handle to EDIT_PROBE_LENGTH (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of EDIT_PROBE_LENGTH as text
%        str2double(get(hObject,'String')) returns contents of EDIT_PROBE_LENGTH as a double


% --- Executes during object creation, after setting all properties.
function EDIT_PROBE_LENGTH_CreateFcn(hObject, eventdata, handles)
% hObject    handle to EDIT_PROBE_LENGTH (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

% --------------------------------------------------------------------
function MENU_WINDOW_LENGTH_Callback(hObject, eventdata, handles)
% hObject    handle to MENU_WINDOW_LENGTH (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
set(handles.MENU_SAMPLING_TIME,'checked','off');
set(handles.MENU_WINDOW_LENGTH,'checked','on');
handles.WINDOWLENGTHTIME=1;
guidata(hObject, handles);

%---------------------------------------
% Define functions for Calculation
% NOT GUI from here
%---------------------------------------

% -------------------------------------------------------------------------------
% Func_Waveform_Processing Function
% Do the waveform calculation, return waveform, smoothed waveform and.
% corresponding second order BMO.
% Need second order BMO (or first order BMO) function and Smoothed function.
% Thus,
% OneDimensionBMO(INPUT,h)
% KernelFunc(BmoDATA1,thre);
% --------------------------------------------------------------------------------


function [W1,WBMO,S1,SBMO]=Func_Waveform_Processing(handles)
index=handles.WAVEFORMINDEX;
W1=handles.WAVEFORMDATA(index,:);
WBMO=OneDimensionBMO(OneDimensionBMO(W1)); % Here use BMO twice, i.e. Second Order BMO
check=handles.CHECK_SMOOTH;
threshold=handles.SMOOTHSTRENGTH;
if check==0
    S1=0;SBMO=0;
else
    thre=1.5*threshold*max(WBMO);
    ErrorInner=0.002;       % double error for the SmoothDataFun function, suggest ErrorInner>=0.001
    ErrorOuter=0.0005;      % and ErrorOuter>=0.0005, usual set it equal 0.001, otherwise numerical diffusion will occur.
    h=1;T=1;t=1;
    m=handles.DATAWIDTH; %data width
    TestOuterWhile=1;TestInnerWhile=1;
    VigilanceOuterWhile=0;VigilanceInnerWhile=0;
    ITERre=zeros(1,m);
    for i=1:m
        ITERre(i)=W1(i);  % input==W1
    end
    while(TestOuterWhile)  
        ITERmm=ITERre; %--mm means axulliary parameters,  and --re means result
        BmoDATA1=OneDimensionBMO(ITERre);
        KerDATA1=KernelFunc(BmoDATA1,thre); 
        r=t/(h^2);
        for i=2:m-1
            A(i)=-0.5*(KerDATA1(i-1)+KerDATA1(i));
            B(i)=0.5*(KerDATA1(i-1)+KerDATA1(i))+0.5*(KerDATA1(i+1)+KerDATA1(i))+1/r;
            C(i)=-0.5*(KerDATA1(i+1)+KerDATA1(i));
            D(i)=ITERre(i)/r;
        end
        A(1)=0;B(1)=1;C(1)=0;A(m)=0;B(m)=1;C(m)=0;D(1)=ITERre(1);D(m)=ITERre(m);
        R(1)=C(1)/B(1);Y(1)=D(1)/B(1);
        for i=2:m
            R(i)=C(i)/(B(i)-R(i-1)*A(i));
            Y(i)=(D(i)-Y(i-1)*A(i))/(B(i)-R(i-1)*A(i));
        end
        ITER(m)=Y(m);
        for i=m-1:-1:1
            ITER(i)=Y(i)-R(i)*ITER(i+1);
        end
        p=1; 
        while (max(abs(ITER-ITERmm)./ITERmm)>ErrorInner)
            ITERmm=ITER;  % parameters for compare
            p=p+1;
            if p>5
                t=0.5*t;
            end
            BmoDATA1=OneDimensionBMO(ITERre);
            KerDATA1=KernelFunc(BmoDATA1,thre); 
            r=t/(h^2);
            for i=2:m-1
                A(i)=-0.5*(KerDATA1(i-1)+KerDATA1(i));
                B(i)=0.5*(KerDATA1(i-1)+KerDATA1(i))+0.5*(KerDATA1(i+1)+KerDATA1(i))+1/r;
                C(i)=-0.5*(KerDATA1(i+1)+KerDATA1(i));
                D(i)=ITERre(i)/r;
            end
            A(1)=0;B(1)=1;C(1)=0;A(m)=0;B(m)=1;C(m)=0;D(1)=ITERre(1);D(m)=ITERre(m);
            R(1)=C(1)/B(1);Y(1)=D(1)/B(1);
            for i=2:m
                R(i)=C(i)/(B(i)-R(i-1)*A(i));
                Y(i)=(D(i)-Y(i-1)*A(i))/(B(i)-R(i-1)*A(i));
            end
            ITER(m)=Y(m);
            for i=m-1:-1:1
                ITER(i)=Y(i)-R(i)*ITER(i+1);
            end
        end
        diff=max(abs(ITER-ITERre)./ITERre);
        if(diff>ErrorOuter)
            TestOuterWhile=1;
            t=1.25*t;
            ITERre=ITER;
        else
            TestOuterWhile=0;
            ITERre=ITER;
        end
    end
    S1=ITERre;
    SBMO=OneDimensionBMO(OneDimensionBMO(S1)); % Here use BMO twice, i.e. Second Order BMO
end

%---------------------------------------
% KernelFunc
% Need //
%---------------------------------------
function ANS=KernelFunc(INPUT,thre)
m=max(size(INPUT));
ANS=zeros(1,m);
ANS(1)=0;
ANS(m)=0;
for i=2:m-1
	if(INPUT(i)<=thre)
		ANS(i)=1/6;
    else
        ANS(i)=0;
	end
end

%---------------------------------------
% 1-D BMO function (7 points)
% Need //
%---------------------------------------
function ANS=OneDimensionBMO(INPUT)
h=1;
m=max(size(INPUT));
ANS=zeros(1,m);
for i=4:m-3	
	p=((INPUT(i)+INPUT(i-1)+INPUT(i+1)+INPUT(i-2)+INPUT(i+2))+0.5*INPUT(i-3)+0.5*INPUT(i+3))/6;
	q=(((INPUT(i)-p)^2+(INPUT(i+1)-p)^2+(INPUT(i-1)-p)^2+(INPUT(i+2)-p)^2+(INPUT(i+2)-p)^2)+0.5*((INPUT(i+3)-p)^2)+0.5*((INPUT(i-3)-p)^2))/6;
	ANS(i)=sqrt(q)/h;
end
ANS(1)=ANS(4);
ANS(2)=ANS(4);
ANS(3)=ANS(4);
ANS(m)=ANS(m-3);
ANS(m-1)=ANS(m-3);
ANS(m-2)=ANS(m-3);

% -------------------------------------------------------------------------------
% Func_Waveform_Plot Function
% Just plot the results of waveform and corresponding BMO
% Need the results of second order BMO (or first order BMO) function and Smoothed function.
% Thus, Need the results of
% Func_Waveform_Processing(handles)
% --------------------------------------------------------------------------------
function HANDLEPLOT=Func_Waveform_Plot(handles,W1,WBMO,S1,SBMO)
if(handles.AXES_ORIGINAL_WAVEFORM_ORIGINAL~=0)
    delete(handles.AXES_ORIGINAL_WAVEFORM_ORIGINAL);
    handles.AXES_ORIGINAL_WAVEFORM_ORIGINAL=0;
end
if(handles.AXES_SECOND_BMO_ORIGINAL~=0)
    delete(handles.AXES_SECOND_BMO_ORIGINAL);
    handles.AXES_SECOND_BMO_ORIGINAL=0;
end
if(handles.AXES_ORIGINAL_WAVEFORM_SMOOTH~=0)
    delete(handles.AXES_ORIGINAL_WAVEFORM_SMOOTH);
    handles.AXES_ORIGINAL_WAVEFORM_SMOOTH=0;
end
if(handles.AXES_SECOND_BMO_SMOOTH~=0)
    delete(handles.AXES_SECOND_BMO_SMOOTH);
    handles.AXES_SECOND_BMO_SMOOTH=0;
end

check=handles.CHECK_SMOOTH;
X=0:1:(length(W1)-1);
if check==0
    axes(handles.AXES_ORIGINAL_WAVEFORM);
    hold on
    handles.AXES_ORIGINAL_WAVEFORM_ORIGINAL=plot(X,W1,'b');
    ylabel('Reflection Coefficient'),
    hold off
    axes(handles.AXES_SECOND_BMO);
    hold on
    handles.AXES_SECOND_BMO_ORIGINAL=plot(X,WBMO,'b');
    xlabel('Point Index'),ylabel('Second Order BMO'),
    hold off
else
    axes(handles.AXES_ORIGINAL_WAVEFORM);
    hold on
    handles.AXES_ORIGINAL_WAVEFORM_ORIGINAL=plot(X,W1,'b');
    handles.AXES_ORIGINAL_WAVEFORM_SMOOTH=plot(X,S1,'g');
    ylabel('Reflection Coefficient')
    hold off
    axes(handles.AXES_SECOND_BMO);
    hold on
    handles.AXES_SECOND_BMO_ORIGINAL=plot(X,WBMO,'b');
    handles.AXES_SECOND_BMO_SMOOTH=plot(X,SBMO,'g');
    xlabel('Point Index'),ylabel('Second Order BMO');
    hold off
end
HANDLEPLOT=[handles.AXES_ORIGINAL_WAVEFORM_ORIGINAL
handles.AXES_SECOND_BMO_ORIGINAL
handles.AXES_ORIGINAL_WAVEFORM_SMOOTH
handles.AXES_SECOND_BMO_SMOOTH];


%-------------------------------------------
% Do / UNDO first reflection position by manual setting.
% Use the whole handle.
% Delete all but redo the manually setting
% Return only the handle of the first reflection position.
% Use in all the function related to draw the first reflection position,
% including the <<previous and next>> func
% Need //
%-------------------------------------------
function HANDLEPLOT_MANU_FIRREF=Func_Waveform_Plot_FirstManu(handles)
m=handles.FIRSTREFMETHOD;
if(handles.AXES_ORIGINAL_WAVEFORM_FIRSTREF~=0)
    delete(handles.AXES_ORIGINAL_WAVEFORM_FIRSTREF);
    handles.AXES_ORIGINAL_WAVEFORM_FIRSTREF=0;
end
if(handles.AXES_SECOND_BMO_FIRSTREF~=0)
    delete(handles.AXES_SECOND_BMO_FIRSTREF);
    handles.AXES_SECOND_BMO_FIRSTREF=0;
end
if m==4
    FirRef=str2double(get(handles.EDIT_MANUAL_FIRSTREF,'string'));
    axes(handles.AXES_ORIGINAL_WAVEFORM);
    hold on
    handles.AXES_ORIGINAL_WAVEFORM_FIRSTREF=plot([FirRef,FirRef],[min(handles.TEMPW1),max(handles.TEMPW1)],'r');
    hold off
    axes(handles.AXES_SECOND_BMO);
    hold on
    handles.AXES_SECOND_BMO_FIRSTREF=plot([FirRef,FirRef],[0,max(handles.TEMPWBMO)*1.1],'r');
    hold off
end
HANDLEPLOT_MANU_FIRREF=[handles.AXES_ORIGINAL_WAVEFORM_FIRSTREF
handles.AXES_SECOND_BMO_FIRSTREF];

%--------------------------------------
% Automatical First Ref Determination Function, need all the handles.
% Four method are metioned here, need calculations except for manual one
% Return the first reflection position as the POINT INDEX
% Return the first reflection position PLOT HANDLE
%--------------------------------------
function FIRSTREF=Auto_First_Ref_Position(handles)
FIRSTREF=zeros(3,1);

    L=handles.DATAWIDTH;
    if handles.CHECK_SMOOTH==0
        Wave=handles.TEMPW1;
        WaveBMO=handles.TEMPWBMO;
    else
        Wave=handles.TEMPS1;
        WaveBMO=handles.TEMPSBMO;
    end

    LocalMin=find(Wave<=min(Wave));
    LocalMin=LocalMin(1);
    M=max(WaveBMO(1:LocalMin));
    
m=handles.FIRSTREFMETHOD;

% clean previous first refs
if m~=4
    if(handles.AXES_ORIGINAL_WAVEFORM_FIRSTREF~=0)
        delete(handles.AXES_ORIGINAL_WAVEFORM_FIRSTREF);
        handles.AXES_ORIGINAL_WAVEFORM_FIRSTREF=0;
    end
    if(handles.AXES_SECOND_BMO_FIRSTREF~=0)
        delete(handles.AXES_SECOND_BMO_FIRSTREF);
        handles.AXES_SECOND_BMO_FIRSTREF=0;
    end
end

% Second BMO first reflection
if m==1
    EpsFirst=0.01;

    TempPick2=zeros(1,L);

    for i=4:LocalMin
        if(WaveBMO(i)>=WaveBMO(i+1)&&WaveBMO(i)>=WaveBMO(i-1)&&WaveBMO(i)>=WaveBMO(i-2)&&WaveBMO(i)>=WaveBMO(i+2)&&WaveBMO(i)>=WaveBMO(i-3)&&WaveBMO(i)>=WaveBMO(i+3))
            if (WaveBMO(i)>=(1-handles.SENSITIVITYSTRENGTH)*M)
                TempPick2(i)=1;
            end
        end
    end
    
    % find the first reflection position
    % find slope 
    Indices=find(TempPick2(1:LocalMin)==1);
    LIndices=length(Indices);
    WaveIndices=zeros(LIndices+2,1);
    WaveIndices(1)=Wave(1);
    WaveIndices(LIndices+2)=Wave(LocalMin);
    for i=1:LIndices
        WaveIndices(i+1)=Wave(Indices(i));
    end
    kmid=1;
    
    XaxisMax=0;
    
    for i=2:LIndices+1
        if((WaveIndices(i+1)-WaveIndices(i))>(WaveIndices(i)-WaveIndices(i-1)))
        else
            if(kmid==1)
                XaxisMax=Indices(i-1);
            end
        end
    end
    
    if XaxisMax==0;
        LL=find(TempPick2==1);
        XaxisMax=max(2,LL(1));
    end
    
    % spline interpolation
    Interval1=(XaxisMax-2):(XaxisMax+2);
    for i=1:5
        YInterval1(i)=WaveBMO(XaxisMax-3+i);
    end
    PInterval1=(XaxisMax-2):EpsFirst:(XaxisMax+2);
    SplInterval1=spline(Interval1,YInterval1,PInterval1);
    LocX1=find(SplInterval1>=max(SplInterval1));
    XaxisMax=XaxisMax-2+(LocX1-1)*EpsFirst;
    
    % give the first reflection position: -1 because we set first pt as 0
    FIRSTREF(1)=XaxisMax-1;
    
    % plot the first reflection position:
    if (handles.AXES_ORIGINAL_WAVEFORM_FIRSTREF~=0)
        delete(handles.AXES_ORIGINAL_WAVEFORM_FIRSTREF);
        handles.AXES_ORIGINAL_WAVEFORM_FIRSTREF=0;
    end
    axes(handles.AXES_ORIGINAL_WAVEFORM);
    hold on
    FIRSTREF(2)=plot([FIRSTREF(1),FIRSTREF(1)],[min(handles.TEMPW1),max(handles.TEMPW1)],'r');
    hold off
    if (handles.AXES_SECOND_BMO_FIRSTREF~=0)
        delete(handles.AXES_SECOND_BMO_FIRSTREF);
        handles.AXES_SECOND_BMO_FIRSTREF=0;
    end
    axes(handles.AXES_SECOND_BMO);
    hold on
    FIRSTREF(3)=plot([FIRSTREF(1),FIRSTREF(1)],[0,max(handles.TEMPWBMO)*1.1],'r');
    hold off
end

% Tangent line first reflection position
if m==2
    M=max(WaveBMO(1:LocalMin));
    m=find(WaveBMO(1:LocalMin)>=M);
    maxpoint=m(1);
    FirstOrderBMO=OneDimensionBMO(Wave);
    Decent=find(FirstOrderBMO(maxpoint+1:LocalMin-1)>=max(FirstOrderBMO(maxpoint+1:LocalMin-1)));
    Ascent=find(FirstOrderBMO(1:maxpoint-1)>=max(FirstOrderBMO(1:maxpoint-1)));
    Decent=Decent(1);
    Ascent=Ascent(length(Ascent));
    AscentP=Ascent;
    DecentP=maxpoint+3;%Decent % actual maximum decent point
    XaxisMax=(Wave(DecentP)-Wave(AscentP)+FirstOrderBMO(AscentP)*AscentP+FirstOrderBMO(DecentP)*DecentP)/(FirstOrderBMO(AscentP)+FirstOrderBMO(DecentP));
    
    % give the first reflection position: -1 because we set first pt as 0
    FIRSTREF(1)=XaxisMax-1;
    
    % plot the first reflection position:
    if (handles.AXES_ORIGINAL_WAVEFORM_FIRSTREF~=0)
        delete(handles.AXES_ORIGINAL_WAVEFORM_FIRSTREF);
        handles.AXES_ORIGINAL_WAVEFORM_FIRSTREF=0;
    end
    axes(handles.AXES_ORIGINAL_WAVEFORM);
    hold on
    FIRSTREF(2)=plot([FIRSTREF(1),FIRSTREF(1)],[min(handles.TEMPW1),max(handles.TEMPW1)],'r');
    hold off
    if (handles.AXES_SECOND_BMO_FIRSTREF~=0)
        delete(handles.AXES_SECOND_BMO_FIRSTREF);
        handles.AXES_SECOND_BMO_FIRSTREF=0;
    end
    axes(handles.AXES_SECOND_BMO);
    hold on
    FIRSTREF(3)=plot([FIRSTREF(1),FIRSTREF(1)],[0,max(handles.TEMPWBMO)*1.1],'r');
    hold off
end

% Tangent heap first reflection position
% Default set the tolerance interval as 1.5 slope /1 interception points
if m==3
    EpsFirst=0.01;
    M=max(Wave(3:LocalMin));
    m=find(Wave(3:LocalMin)>=M);
    Len=length(m);
    maxpoint=m(Len); % maximum point of waveform
    
    %{
    slope1=Wave(maxpoint-1)-Wave(maxpoint-2);
    slope2=Wave(maxpoint+2)-Wave(maxpoint+1);
    if slope1==0&&slope2==0
        FIRSTREF(1)=maxpoint-1;
    elseif slope1==slope2
        FIRSTREF(1)=maxpoint-1;
    else
        FIRSTREF(1)=((Wave(maxpoint-1)-Wave(maxpoint+1))-slope1*(maxpoint-1)+slope2*(maxpoint+1))/(slope2-slope1)-1;
    end
    %}
    
    % spline interpolation
    Interval1=(maxpoint-1):(maxpoint+1);   % spline interval
    for i=1:5
        YInterval1(i)=WaveBMO(maxpoint-3+i);
    end
    PInterval1=(maxpoint-1):EpsFirst:(maxpoint+1); % spline interval
    SplInterval1=spline(Interval1,YInterval1,PInterval1);
    LocX1=find(SplInterval1>=max(SplInterval1));
    FIRSTREF(1)=maxpoint-2+(LocX1-1)*EpsFirst;
    
    % add weighted to maxpoint
    FIRSTREF(1)=0.15*FIRSTREF(1)+0.85*maxpoint;
    
        
    % plot the first reflection position:
    if (handles.AXES_ORIGINAL_WAVEFORM_FIRSTREF~=0)
        delete(handles.AXES_ORIGINAL_WAVEFORM_FIRSTREF);
        handles.AXES_ORIGINAL_WAVEFORM_FIRSTREF=0;
    end
    axes(handles.AXES_ORIGINAL_WAVEFORM);
    hold on
    FIRSTREF(2)=plot([FIRSTREF(1),FIRSTREF(1)],[min(handles.TEMPW1),max(handles.TEMPW1)],'r');
    hold off
    if (handles.AXES_SECOND_BMO_FIRSTREF~=0)
        delete(handles.AXES_SECOND_BMO_FIRSTREF);
        handles.AXES_SECOND_BMO_FIRSTREF=0;
    end
    axes(handles.AXES_SECOND_BMO);
    hold on
    FIRSTREF(3)=plot([FIRSTREF(1),FIRSTREF(1)],[0,max(handles.TEMPWBMO)*1.1],'r');
    hold off
end

% Manual set first reflection position
if m==4
    FIRSTREF(1)=str2double(get(handles.EDIT_MANUAL_FIRSTREF,'String'));
    if (handles.AXES_ORIGINAL_WAVEFORM_FIRSTREF==0)
        axes(handles.AXES_ORIGINAL_WAVEFORM);
        hold on
        FIRSTREF(2)=plot([FIRSTREF(1),FIRSTREF(1)],[min(handles.TEMPW1),max(handles.TEMPW1)],'r');
        hold off
    else
        FIRSTREF(2)=handles.AXES_ORIGINAL_WAVEFORM_FIRSTREF;
    end
    if (handles.AXES_SECOND_BMO_FIRSTREF==0)
        axes(handles.AXES_SECOND_BMO);
        hold on
        FIRSTREF(3)=plot([FIRSTREF(1),FIRSTREF(1)],[0,max(handles.TEMPWBMO)*1.1],'r');
        hold off
    else
        FIRSTREF(3)=handles.AXES_SECOND_BMO_FIRSTREF;
    end
end

%--------------------------------------
% Automatical Second Ref Determination Function, need all the handles.
% Second order BMO metioned here
% Return the second reflection position as the POINT INDEX
% Return the second reflection position PLOT HANDLE
%--------------------------------------
function SECONDREF=Auto_Second_Ref_Position(handles)

SECONDREF=zeros(3,1);
EpsSecond=0.01;
L=handles.DATAWIDTH;

    if handles.CHECK_SMOOTH==0
        Wave=handles.TEMPW1;
        WaveAxu=handles.TEMPW1;
        WaveBMO=handles.TEMPWBMO;
    else
        WaveAxu=handles.TEMPW1;
        Wave=handles.TEMPS1;
        WaveBMO=handles.TEMPSBMO;
    end

    LocalMin=find(WaveAxu<=min(WaveAxu));
    LocalMin=LocalMin(1);
    LeftEnd=LocalMin;
    
    % begin tangent line pretreatment
    SmoothWave=WaveAxu;
    for i=2:L-1
        SmoothWave(i)=(SmoothWave(i-1)+SmoothWave(i)+SmoothWave(i+1))/3;
    end
    for i=2:L
        DiffWave(i)=SmoothWave(i)-SmoothWave(i-1);
    end
    DiffWave(1)=DiffWave(2);
    SecondInflation=find(DiffWave(LeftEnd:L)>=max(DiffWave(LeftEnd:L)),1,'first')+(LeftEnd-1);
    SecFlat=SecondInflation+(WaveAxu(LeftEnd)-WaveAxu(SecondInflation))/DiffWave(SecondInflation);
    SecFlat=round(SecFlat);
    Y=WaveAxu(LeftEnd:SecFlat);
    X=LeftEnd:SecFlat;
    Cov=cov(X,Y); MeaX=mean(X);MeaY=mean(Y); bR=Cov(1,2)/Cov(1,1); aR=MeaY-bR*MeaX;
    SecRegr=(aR-WaveAxu(SecondInflation)+DiffWave(SecondInflation)*SecondInflation)/(DiffWave(SecondInflation)-bR);
    SecRegr=round(SecRegr);
    RightEnd=min([SecFlat+10,SecRegr+10,SecondInflation,L-3]);
    LeftEnd=max([LeftEnd,SecFlat-10,SecRegr-10]);
        
    % end tangent line pretreatment
    
    M=max(WaveBMO(LeftEnd:RightEnd));
    TempPick2=zeros(1,L);
    
for i=LeftEnd:RightEnd
    if(WaveBMO(i)>=WaveBMO(i+1)&&WaveBMO(i)>=WaveBMO(i-1)&&WaveBMO(i)>=WaveBMO(i-2)&&WaveBMO(i)>=WaveBMO(i+2)&&WaveBMO(i)>=WaveBMO(i-3)&&WaveBMO(i)>=WaveBMO(i+3))
        if (WaveBMO(i)>=(1-handles.SENSITIVITYSTRENGTH)*M)
            TempPick2(i)=1;
        end
    end
end

% determine the second reflection position
Indices=find(TempPick2(LeftEnd:L)==1);

Indices=Indices+(LeftEnd-1);
LIndices=length(Indices);
WaveValIndices=zeros(LIndices+2,1);
WaveValIndices(1)=Wave(LeftEnd);
WaveValIndices(LIndices+2)=Wave(RightEnd);
for i=1:LIndices
    WaveValIndices(i+1)=Wave(Indices(i));
end
kmid=1;

XaxisMax=0;

for i=2:LIndices+1
    if((WaveValIndices(i+1)-WaveValIndices(i))<(WaveValIndices(i)-WaveValIndices(i-1)))
    else
        if(kmid==1)
            XaxisMax=Indices(i-1);
            kmid=kmid+1;
        end
    end
end

if XaxisMax==0;
    LL=find(TempPick2==1);
    XaxisMax=min(L-3,LL(1));
end

% spline interpolation
Interval1=(XaxisMax-2):(XaxisMax+2);
for i=1:5
    YInterval1(i)=WaveBMO(XaxisMax-3+i);
end
PInterval1=(XaxisMax-2):EpsSecond:(XaxisMax+2);
SplInterval1=spline(Interval1,YInterval1,PInterval1);
LocX1=find(SplInterval1>=max(SplInterval1));
XaxisMax=XaxisMax-2+(LocX1-1)*EpsSecond;
    
% give the first reflection position: -1 because we set first pt as 0
SECONDREF(1)=XaxisMax-1;
    
% plot the second reflection position:
if (handles.AXES_ORIGINAL_WAVEFORM_SECREF~=0)
    delete(handles.AXES_ORIGINAL_WAVEFORM_SECREF);
    handles.AXES_ORIGINAL_WAVEFORM_SECREF=0;
end
axes(handles.AXES_ORIGINAL_WAVEFORM);
hold on
SECONDREF(2)=plot([SECONDREF(1),SECONDREF(1)],[min(handles.TEMPW1),max(handles.TEMPW1)],'r');
hold off
if (handles.AXES_SECOND_BMO_SECREF~=0)
    delete(handles.AXES_SECOND_BMO_SECREF);
    handles.AXES_SECOND_BMO_SECREF=0;
end
axes(handles.AXES_SECOND_BMO);
hold on
SECONDREF(3)=plot([SECONDREF(1),SECONDREF(1)],[0,max(handles.TEMPWBMO)*1.1],'r');
hold off

%--------------------------------------
% Manually First Ref Determination Function, need all the handles.
% Clean the handles, except the manually set first ref, i.e. m=4
% Return the first reflection position as the POINT INDEX
% Return the first reflection position PLOT HANDLE
%--------------------------------------
function FIRSTREF=Manual_First_Ref_Position(handles)
FIRSTREF=zeros(3,1);
EpsFirst=0.01;

    if handles.CHECK_SMOOTH==0
        WaveBMO=handles.TEMPWBMO;
    else
        WaveBMO=handles.TEMPSBMO;
    end
    
m=handles.FIRSTREFMETHOD;

% clean previous first refs
if m~=4
    if(handles.AXES_ORIGINAL_WAVEFORM_FIRSTREF~=0)
        delete(handles.AXES_ORIGINAL_WAVEFORM_FIRSTREF);
        handles.AXES_ORIGINAL_WAVEFORM_FIRSTREF=0;
    end
    if(handles.AXES_SECOND_BMO_FIRSTREF~=0)
        delete(handles.AXES_SECOND_BMO_FIRSTREF);
        handles.AXES_SECOND_BMO_FIRSTREF=0;
    end
end

if m~=4
    SetInitialValue=ginput(2);
    SetInitialValue=floor(SetInitialValue(:,1))+1;
    SetInitialValue(2)=SetInitialValue(2)+1;
    kink=0;
    for i=SetInitialValue(1):SetInitialValue(2)
        if(WaveBMO(i)>=WaveBMO(i+1)&&WaveBMO(i)>=WaveBMO(i-1)&&WaveBMO(i)>=WaveBMO(i-2)&&WaveBMO(i)>=WaveBMO(i+2))
            kink=kink+1;
            XaxisMax(kink)=i;
        end
    end
    if kink==0;
        XaxisMax=find(WaveBMO(SetInitialValue(1):SetInitialValue(2))>=max(WaveBMO(SetInitialValue(1):SetInitialValue(2))));
        XaxisMax=XaxisMax(1)+SetInitialValue(1)-1;
    end
    if kink>1;
        Potential=1;
        for i=1:kink;
            if WaveBMO(XaxisMax(Potential))<=WaveBMO(XaxisMax(i))
                Potential=i;
            end
        end
        XaxisMax=Potential;
    end
    
    % spline interpolation
    Interval=(XaxisMax-2):(XaxisMax+2);
    for i=1:5
        YInterval(i)=WaveBMO(XaxisMax-3+i);
    end
    PInterval=(XaxisMax-2):EpsFirst:(XaxisMax+2);
    SplInterval2=spline(Interval,YInterval,PInterval);
    LocX=find(SplInterval2>=max(SplInterval2));
    XaxisMax=XaxisMax-2+(LocX-1)*EpsFirst;
    
    FIRSTREF(1)=XaxisMax-1;
    
    % plot the first reflection position
    if (handles.AXES_ORIGINAL_WAVEFORM_FIRSTREF~=0)
        delete(handles.AXES_ORIGINAL_WAVEFORM_FIRSTREF);
        handles.AXES_ORIGINAL_WAVEFORM_FIRSTREF=0;
    end
    axes(handles.AXES_ORIGINAL_WAVEFORM);
    hold on
    FIRSTREF(2)=plot([FIRSTREF(1),FIRSTREF(1)],[min(handles.TEMPW1),max(handles.TEMPW1)],'r');
    hold off
    if (handles.AXES_SECOND_BMO_FIRSTREF~=0)
        delete(handles.AXES_SECOND_BMO_FIRSTREF);
        handles.AXES_SECOND_BMO_FIRSTREF=0;
    end
    axes(handles.AXES_SECOND_BMO);
    hold on
    FIRSTREF(3)=plot([FIRSTREF(1),FIRSTREF(1)],[0,max(handles.TEMPWBMO)*1.1],'r');
    hold off
end

% Manual set first reflection position
if m==4
    FIRSTREF(1)=str2double(get(handles.EDIT_MANUAL_FIRSTREF,'String'));
    if (handles.AXES_ORIGINAL_WAVEFORM_FIRSTREF==0)
        axes(handles.AXES_ORIGINAL_WAVEFORM);
        hold on
        FIRSTREF(2)=plot([FIRSTREF(1),FIRSTREF(1)],[min(handles.TEMPW1),max(handles.TEMPW1)],'r');
        hold off
    else
        FIRSTREF(2)=handles.AXES_ORIGINAL_WAVEFORM_FIRSTREF;
    end
    if (handles.AXES_SECOND_BMO_FIRSTREF==0)
        axes(handles.AXES_SECOND_BMO);
        hold on
        FIRSTREF(3)=plot([FIRSTREF(1),FIRSTREF(1)],[0,max(handles.TEMPWBMO)*1.1],'r');
        hold off
    else
        FIRSTREF(3)=handles.AXES_SECOND_BMO_FIRSTREF;
    end
end

%--------------------------------------
% Manually Second Ref Determination Function, need all the handles.
% Return the second reflection position as the POINT INDEX
% Return the second reflection position PLOT HANDLE
%--------------------------------------
function SECONDREF=Manual_Second_Ref_Position(handles)
SECONDREF=zeros(3,1);
EpsSecond=0.01;

    if handles.CHECK_SMOOTH==0
        WaveBMO=handles.TEMPWBMO;
    else
        WaveBMO=handles.TEMPSBMO;
    end
    
    SetInitialValue=ginput(2);
    SetInitialValue=floor(SetInitialValue(:,1))+1;
    SetInitialValue(2)=SetInitialValue(2)+1;
    kink=0;
    for i=SetInitialValue(1):SetInitialValue(2)
        if(WaveBMO(i)>=WaveBMO(i+1)&&WaveBMO(i)>=WaveBMO(i-1)&&WaveBMO(i)>=WaveBMO(i-2)&&WaveBMO(i)>=WaveBMO(i+2))
            kink=kink+1;
            XaxisMax(kink)=i;
        end
    end
    if kink==0;
        XaxisMax=find(WaveBMO(SetInitialValue(1):SetInitialValue(2))>=max(WaveBMO(SetInitialValue(1):SetInitialValue(2))));
        XaxisMax=XaxisMax(1)+SetInitialValue(1)-1;
    end
    if kink>1;
        Potential=1;
        for i=1:kink;
            if WaveBMO(XaxisMax(Potential))<=WaveBMO(XaxisMax(i))
                Potential=i;
            end
        end
        XaxisMax=Potential;
    end
    
    % spline interpolation
    Interval=(XaxisMax-2):(XaxisMax+2);
    for i=1:5
        YInterval(i)=WaveBMO(XaxisMax-3+i);
    end
    PInterval=(XaxisMax-2):EpsSecond:(XaxisMax+2);
    SplInterval2=spline(Interval,YInterval,PInterval);
    LocX=find(SplInterval2>=max(SplInterval2));
    XaxisMax=XaxisMax-2+(LocX-1)*EpsSecond;
    
    SECONDREF(1)=XaxisMax-1;
    
    
% plot the second reflection position:
if (handles.AXES_ORIGINAL_WAVEFORM_SECREF~=0)
    delete(handles.AXES_ORIGINAL_WAVEFORM_SECREF);
    handles.AXES_ORIGINAL_WAVEFORM_SECREF=0;
end
axes(handles.AXES_ORIGINAL_WAVEFORM);
hold on
SECONDREF(2)=plot([SECONDREF(1),SECONDREF(1)],[min(handles.TEMPW1),max(handles.TEMPW1)],'r');
hold off
if (handles.AXES_SECOND_BMO_SECREF~=0)
    delete(handles.AXES_SECOND_BMO_SECREF);
    handles.AXES_SECOND_BMO_SECREF=0;
end
axes(handles.AXES_SECOND_BMO);
hold on
SECONDREF(3)=plot([SECONDREF(1),SECONDREF(1)],[0,max(handles.TEMPWBMO)*1.1],'r');
hold off

%---------------------------------------
% Clean_Figures
% Use to clean the figures in open callback function.
% Need //
%---------------------------------------
function Clean_Figures(handles)
    if(handles.AXES_ORIGINAL_WAVEFORM_ORIGINAL~=0)
        delete(handles.AXES_ORIGINAL_WAVEFORM_ORIGINAL);
    end
    if(handles.AXES_SECOND_BMO_ORIGINAL~=0)
        delete(handles.AXES_SECOND_BMO_ORIGINAL);
    end
    if(handles.AXES_ORIGINAL_WAVEFORM_SMOOTH~=0)
        delete(handles.AXES_ORIGINAL_WAVEFORM_SMOOTH);
    end
    if(handles.AXES_SECOND_BMO_SMOOTH~=0)
        delete(handles.AXES_SECOND_BMO_SMOOTH);
    end
    if(handles.AXES_ORIGINAL_WAVEFORM_FIRSTREF~=0)
        delete(handles.AXES_ORIGINAL_WAVEFORM_FIRSTREF);
    end
    if(handles.AXES_SECOND_BMO_FIRSTREF~=0)
        delete(handles.AXES_SECOND_BMO_FIRSTREF);
    end
    if(handles.AXES_ORIGINAL_WAVEFORM_SECREF~=0)
        delete(handles.AXES_ORIGINAL_WAVEFORM_SECREF);
    end
    if(handles.AXES_SECOND_BMO_SECREF~=0)
        delete(handles.AXES_SECOND_BMO_SECREF);
    end
    
    
%---------------------------------------
% ToppEq function
% Need //
%---------------------------------------
function y=ToppEq(x)
y=(-0.053)+(0.0292*x)+(-0.00055*x*x)+(0.0000043*x*x*x);
